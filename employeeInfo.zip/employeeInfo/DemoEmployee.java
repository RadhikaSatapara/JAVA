package employeeInfo;

public class DemoEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Employee e1 = new Employee();
		
		e1.setEname("radhika");
		e1.setEmail("radhisatapara@gmail.com");
		
		Employee e2 = new Employee();
		
		e2.setEname("radhika");
		e2.setEmail("radhikaSatapara@gmail.com");
		
		
		//System.out.println(e1.getEname() +  "  " +e1.getEmail()) ;

		
		System.out.println(e1);   //e1.toString()
		
		System.out.println(e2);
	}

}
