package userdefinedexception;

public class DemoException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Thread t = new Thread();
	  System.out.println( 	t.getName()); 
		//Employee e1 = new Employee();
			//e1.setEname("Janaki");
			//e1.setSalary(2000);

	}

}
