package exceptionExample.throwexample;

public class DemoTHrow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThrowExample te = new ThrowExample();
		te.setMarks(-12);
		System.out.println(te);
	}

}
