package functionalinterface;

public class DefaultExample implements Register {
	
	public void getID() {
		System.out.println("i am from class");
	}
	public void showReceipt() {
		
		System.out.println("My REceipt");
	}

}
