package functionalinterface;

public class FunctionalInterface1  implements GreetInterface {

	
	@Override
	public void sayHello() {
		System.out.println("Welcome to the platform!!!");
	}
}

