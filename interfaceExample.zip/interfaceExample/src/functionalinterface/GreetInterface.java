package functionalinterface;

 
public interface GreetInterface  extends Register {

	void sayHello();
	  void getID() ;
	
}
