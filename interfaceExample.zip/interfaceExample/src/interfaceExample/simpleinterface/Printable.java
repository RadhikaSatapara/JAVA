package interfaceExample.simpleinterface;

public interface Printable  {
	int MIN=100;    //static and final
	void showData() ;  //public abstarct
	 
}
