package interfaceExample;

public class TestInterface implements Printable,CheckData {
	@Override
	
	 public void printData() {
		System.out.println("Hello");
	}

}
