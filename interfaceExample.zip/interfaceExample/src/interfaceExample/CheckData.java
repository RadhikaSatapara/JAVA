package interfaceExample;

public interface CheckData {
	
	String str = "Check";

}
