package interfaceExample;

public class DemoInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TestInterface ti = new TestInterface();
		
		ti.printData();
	//	TestInterface.str="fff";
		System.out.println(TestInterface.str);
	}

}
