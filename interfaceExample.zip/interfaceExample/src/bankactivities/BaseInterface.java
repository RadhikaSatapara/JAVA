package bankactivities;

public interface BaseInterface {
	String str = "Welcome";

}
