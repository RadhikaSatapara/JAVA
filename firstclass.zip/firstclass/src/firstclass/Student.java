package firstclass;

public class Student {
	
	
	private int rollno,mobile;
   private String	name,email; 
	
  void setrollno(int no) {
	    rollno=no;
  }
  int getrollno() {
	  return rollno;
  }

}
