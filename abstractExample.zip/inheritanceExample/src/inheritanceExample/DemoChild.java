package inheritanceExample;

public class DemoChild {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*ChildClass ch = new ChildClass();
		
		
		ch.setAmt(12000);
		System.out.println(ch);*/
		
		
		
		NextChild nc = new NextChild();
		
		
	}

}
