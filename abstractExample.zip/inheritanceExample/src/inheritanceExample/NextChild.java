package inheritanceExample;

public class NextChild  extends ChildClass {

}
