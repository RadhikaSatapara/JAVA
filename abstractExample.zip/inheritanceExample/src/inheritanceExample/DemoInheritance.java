package inheritanceExample;

public class DemoInheritance {

	public static void main(String[] args) {
		ChildClass chd = new ChildClass();
		chd.setAmt(12000);
		chd.intro();
		System.out.println(chd);
	}

}
