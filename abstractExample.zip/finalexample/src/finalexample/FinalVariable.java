package finalexample;

final class TEst{
	
}
public class FinalVariable   {
   final int salary;
   
   public  FinalVariable(){
	   salary=89;
   }
    
   
   public final void show() {
	   //TEst te = new TEst();
	   System.out.println("I am Final Function");
   }

}
