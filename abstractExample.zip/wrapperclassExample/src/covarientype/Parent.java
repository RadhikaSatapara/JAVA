package covarientype;

public class Parent {
	
	public String display()
	{
		System.out.println("I am Parent");
	}

}
