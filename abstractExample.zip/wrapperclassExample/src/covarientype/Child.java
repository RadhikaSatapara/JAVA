package covarientype;

public class Child extends Parent {
	@Override
	public String display() {
		System.out.println("I am Child");
		
	}

}
