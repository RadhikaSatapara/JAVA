package abstractExample;

public class Addition extends MyTest {
	
	private int no,no1;
	
	public Addition() {
		no=30;
		no1=89;
	}
	@Override
	public void showResult() {
		 
		
	 
		System.out.println(this.no  + this.no1 );
		
	}

}
