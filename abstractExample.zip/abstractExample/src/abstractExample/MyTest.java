package abstractExample;

public  abstract class MyTest {
	
	public void calculate() {
		System.out.println("calculation");
	}
	
	
	public abstract void showResult() ;


}
