package firstclass;

public class FirstClass2 {

	public static void main(String[] args) {
	
		
		Student st= new Student();
		
		st.setrollno(5);
		
	
	 
	 System.out.println(st.getrollno());
		
		int no,no1;
		no=10;
		no1=4;
		
		System.out.println("result="+(float) no/no1);
		
		
	}

}
