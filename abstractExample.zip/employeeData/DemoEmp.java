package employeeData;

public class DemoEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmployeeData ed = new EmployeeData();
		ed.setName("abc");
		ed.setDesignation("xyz");
		ed.setBasicSalary(50000);
		
		
		System.out.println(ed);
	}

}
