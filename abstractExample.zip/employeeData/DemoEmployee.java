package employeeData;

public class DemoEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		  EmpPersonalInfo epr = new EmpPersonalInfo();
		  

epr.setEname("abcs");
epr.setEmailId("abcs@gmail.com");
epr.setResaddr("xyz");
epr.setMobileno(123456);


System.out.println(epr);  //  epr.toString() 


//System.out.println(epr.getEname() + " " + epr.getEmailId() + " " + epr.getMobileno());
	
	
EmpPersonalInfo epr1 = new EmpPersonalInfo();
	epr1.setEname("mno");
	epr1.setResaddr("On the tree");
	
	
	System.out.println(epr1);  //epr1.toString()
	
	
	}

}
