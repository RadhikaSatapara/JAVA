package interfaceExample;

public interface Printable {
	
	int min=500;  // final and static
	
	void printData(); // public and abstract 
	

}
