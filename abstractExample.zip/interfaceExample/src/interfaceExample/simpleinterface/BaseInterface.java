package interfaceExample.simpleinterface;

public interface BaseInterface {
	String msg="Welcome to the Coding World";

}
