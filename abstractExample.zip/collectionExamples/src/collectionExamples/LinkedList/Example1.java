package collectionExamples.linkedlist;

import java.util.List;
import java.util.LinkedList;

public class Example1 {

	public static void main(String[] args) {

		List l2 = new LinkedList();

		l2.add("radhika");
		l2.add("janvi");
		l2.add("neha");
		
		
		System.out.println(l2);
	 

		
		  	}

}
