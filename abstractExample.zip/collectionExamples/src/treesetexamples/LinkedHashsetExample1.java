package treesetexamples;

import java.util.LinkedHashSet;

public class LinkedHashsetExample1 {

	public static void main(String[] args) {
	
		
	LinkedHashSet <String> lh1 = new LinkedHashSet<String>();  
	lh1.add("radhika");
	lh1.add("janvi");
	lh1.add("Mitesh");
	lh1.add("kaushik");
	
	System.out.println(lh1);
	
	lh1.forEach(l -> System.out.println(l));
	
	
	
	
	}

}
