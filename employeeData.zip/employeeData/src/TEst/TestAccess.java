package TEst;

import employeeData.EmpPersonalInfo;

public class TestAccess {

	public static void main(String[] args) {
		

		
		EmpPersonalInfo  ei = new EmpPersonalInfo();
		
	
	}

}
