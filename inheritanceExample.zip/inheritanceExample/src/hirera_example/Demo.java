package hirera_example;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student st = new Student();
		
		
		st.setName("radhika");
		st.setCity("ahm");
		st.setDiv("g");
		
		System.out.println(st);
		
Student s2 = new Student("grancy","rajkor","f");
System.out.println(s2);
		//Person p  = new Person();
		//p = new Employee();
	      //  System.out.println(p instanceof Employee);  
	}

}
