package inheritanceExample;

public class SuperBaseClass {
	public void intro() {
		System.out.println("I am super base class");
	}

}
