package inheritanceExample;

public class ChildClass   extends BaseClass{
	
	
	

}
