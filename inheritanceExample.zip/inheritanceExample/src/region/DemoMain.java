package region;

public class DemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		City ct = new City();
		
		ct.setCname("India");
		ct.setSname("Gujarat");
		ct.setCity_name("Ahmedabad");
		
		System.out.println(ct);

	}

}
