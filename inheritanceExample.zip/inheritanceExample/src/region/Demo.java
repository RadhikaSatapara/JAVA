package region;

public class Demo {

	public static void main(String[] args) {
	 City cty = new City();
	 cty.setCname("India");
	 cty.setStname("Gujarat");
	 cty.setCity_name("Ahmedabad");
	 
	 
	 System.out.println( cty );
	}

}
