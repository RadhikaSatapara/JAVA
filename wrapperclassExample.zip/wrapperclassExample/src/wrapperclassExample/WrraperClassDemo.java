package wrapperclassExample;
import java.util.*;
public class WrraperClassDemo {

	public static void main(String[] args) {
		
		int k=32,j,l;
		char ch;
		
		Integer in1 = new Integer(12);
		in1=k;
		in1 = 67;
		
		//List <Integer> ls = new List <Integer>();
		
		Integer.parseInt("23");
		
	}

}
