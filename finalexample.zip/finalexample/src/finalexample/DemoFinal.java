package finalexample;

public class DemoFinal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int val= 13;
		FinalExample1 fn = new FinalExample1(val++);
	}

}
