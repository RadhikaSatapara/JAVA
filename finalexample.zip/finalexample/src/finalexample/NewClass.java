package finalexample;

public class NewClass extends FinalExample1 {
	
	public NewClass() {
		super(23);
	}
	 

}
