package finalexample;

public class ChildClass extends FinalVariable{
	
	
	@Override
	public final void show() {
		   System.out.println("I am Final Function");
	   }

}
