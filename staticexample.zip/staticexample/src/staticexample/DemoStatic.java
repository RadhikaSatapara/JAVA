package staticexample;

public class DemoStatic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ChildClass ch = new ChildClass();
		
		StaticFuntion.showData();
	}

}
