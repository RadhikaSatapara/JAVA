package methodoverrriding;

public class Parent {

	
	public void sayHello(String msg) {
		
		System.out.println(msg);
	}
}
