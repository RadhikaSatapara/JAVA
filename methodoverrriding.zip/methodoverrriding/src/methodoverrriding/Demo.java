package methodoverrriding;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Child ch = new Child();
		//ch.sayHello("Good Morning");
		
		Parent p = new Child();
		
		
		
		p.sayHello("Have aNice Day!!");
		
		//Parent p1 = new Parent();
		//p1.sayHello("Bye ....");
		
		//Child ch = new Parent();
	}

}
